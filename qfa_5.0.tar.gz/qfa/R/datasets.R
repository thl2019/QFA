# -- Datasets of R package qfa: Quantile-Frequency Analysis (QFA) --

#' Engel's food expenditure data
#'
#' Engel's food expenditure data from the R package 'quantreg'.
#' @docType data
#' @usage data(engel)
#' @keywords datasets
#' @references Koenker, R. (2005). Quantile Regression. Cambridge University Press. 
"engel"


#' Yearly sunspot numbers v1.0
#'
#' Yearly mean total sunspot numbers from 1700 to 2007.
#' @docType data
#' @usage data(yearssn)
#' @keywords datasets
#' @references WDC-SILSO, Royal Observatory of Belgium, Brussels. \doi{10.24414/stcz-kc45}
#' @source Original data \url{https://www.sidc.be/SILSO/versionarchive} from WDC-SILSO, Royal Observatory of Belgium, Brussels. 
"yearssn"

#' Yearly sunspot numbers v2.0
#'
#' Yearly mean total sunspot numbers from 1700 to 2024. A revised version replacing v1.0.
#' @docType data
#' @usage data(yearssn2024)
#' @keywords datasets
#' @references WDC-SILSO, Royal Observatory of Belgium, Brussels. \doi{10.24414/qnza-ac80}
#' @source  Original data \url{https://www.sidc.be/SILSO/datafiles} from WDC-SILSO, Royal Observatory of Belgium, Brussels.
"yearssn2"

#' Birth data 
#'
#' A random sample of US birth data in 2022 (birth weight and covariates). \code{Precare} and \code{Education} should be treated as factors.
#' @docType data
#' @usage data(birthweight)
#' @keywords datasets
#' @references Koenker, R. (2005). Quantile Regression. Cambridge University Press. 
#' @source Data file \url{https://data.nber.org/nvss/natality/csv/2022/natality2022us.csv} 
#' from NBER \url{https://www.nber.org/research/data/vital-statistics-natality-birth-data}.
#' Original source from the National Center for Health Statistics \url{http://www.cdc.gov/nchs/births.htm}.
"birthweight"


#' Financial index
#'
#' Daily closing values of DJIA and FTSE 100 on trading days from 2001-11-27 to 2010-03-10.
#' @docType data
#' @usage data(finIndex)
#' @source \url{https://www.wsj.com/market-data/quotes/index/DJIA/historical-prices} and
#'  \url{https://www.wsj.com/market-data/quotes/index/UK/UKX/historical-prices}
#' @keywords datasets
"finIndex"

